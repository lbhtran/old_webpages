GUIDE TO USE THE PYTHON SCRIPT

Download and save the script to Desktop or an appropriate, easy to access folder

1. Open Terminal/Command Prompt
2. Go to the folder containing the scripts
3. Run the script using "python mols.py"
